﻿<!DOCTYPE HTML>
<html>
<head>
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>
  
    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";

        // SQL Bağlantı cümlesi
        $conn = mysqli_connect($servername, $username, $password);

        // SQL Bağlantı Kontrolü
        if (!$conn) {
            die("Bağlantı Başarısız Oldu: " . mysqli_connect_error());
        }
        echo "Bağlantı Başarılı";
?>

    <?php

    $yemekAdiErr = $malzemelerErr = $tarifErr = "";
    $yemekAdi = $malzemeler = $tarif = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $yemekAdiErr = "Yemek Adı Giriniz!";
    } else {
    $name = test_input($_POST["yemekAdi"]);
    }
    if (!preg_match("/^[a-zA-Z-' ]*$/",$yemekAdi)) {
    $yemekAdiErr = "Sadece harf ve boşluk girilebilir";
    }
    }


    if (empty($_POST["malzemeler"])) {
    $malzemeler = "";
    } else {
    $malzemeler = test_input($_POST["malzemeler"]);
    }

    if (empty($_POST["tarif"])) {
    $tarif = "";
    } else {
    $tarif = test_input($_POST["tarif"]);
    }

    function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }
    ?>

    <h2>Yemek Tarifleri</h2>
    <p><span class="error">* Zorunlu Alanlar</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER[" PHP_SELF"]);?>
        ">
        Yemek Adı: <input type="text" name="yemekAdi" value="<?php echo $name;?>">
        <span class="error">* <?php echo $yemekAdiErr;?></span>
        <br><br>
        Malzemeler: <textarea name="malzemeler" rows="5" cols="40"><?php echo $malzemeler;?></textarea>
        <span class="error">* <?php echo $malzemelerErr;?></span>
        <br><br>
        Tarif: <textarea name="tarif" rows="5" cols="40"><?php echo $tarif;?></textarea>
        <span class="error">* <?php echo $tarifErr;?></span>
        <br><br>
        <input type="submit" name="submit" value="Kaydet">
    </form>
    <?php
    echo "<h2>Tarifiniz :</h2>";
    echo $yemekAdi;
    echo "<br>";
    echo $malzemeler;
    echo "<br>";
    echo $tarif;
    echo "<br>";
    
    $sql = "INSERT INTO MyGuests (yemekAdi, malzemeler, tarif)
VALUES ($yemekAdi, $malzemeler, $tarif)";
    ?>



</body>
</html>

<!DOCTYPE HTML>
<html>
<head>
    <style>
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>

    <?php

    $yemekAdiErr = $malzemelerErr = $tarifErr = "";
    $yemekAdi = $malzemeler = $tarif = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["yemekAdi"])) {
    $yemekAdiErr = "Yemek Adı Giriniz!";
    } else {
    $name = test_input($_POST["yemekAdi"]);
    }
    if (!preg_match("/^[a-zA-Z-' ]*$/",$yemekAdi)) {
    $yemekAdiErr = "Sadece harf ve boşluk girilebilir";
    }
    }


    if (empty($_POST["malzemeler"])) {
    $malzemeler = "";
    } else {
    $malzemeler = test_input($_POST["malzemeler"]);
    }

    if (empty($_POST["tarif"])) {
    $tarif = "";
    } else {
    $tarif = test_input($_POST["tarif"]);
    }

    function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }
    ?>

    <h2>Yemek Tarifleri</h2>
    <p><span class="error">* Zorunlu Alanlar</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER[" PHP_SELF"]);?>
        ">
        Yemek Adı: <input type="text" name="yemekAdi" value="<?php echo $name;?>">
        <span class="error">* <?php echo $yemekAdiErr;?></span>
        <br><br>
        Malzemeler: <textarea name="malzemeler" rows="5" cols="40"><?php echo $malzemeler;?></textarea>
        <span class="error">* <?php echo $malzemelerErr;?></span>
        <br><br>
        Tarif: <textarea name="tarif" rows="5" cols="40"><?php echo $tarif;?></textarea>
        <span class="error">* <?php echo $tarifErr;?></span>
        <br><br>
        <input type="submit" name="submit" value="Kaydet">
    </form>
    <?php
    echo "<h2>Tarifiniz :</h2>";
    echo $yemekAdi;
    echo "<br>";
    echo $malzemeler;
    echo "<br>";
    echo $tarif;
    echo "<br>";
    ?>

</body>
</html>

